using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.AI;

namespace Enemy_State
{
    public class EnemyNormal : Enemy
    {
        private void Start()
        {
            this.rb = GetComponent<Rigidbody2D>();
            this.directorAI = FindObjectOfType<DirectorAI>();
            this.agent = GetComponent<NavMeshAgent>();
            this.agent.updateRotation = false;
            this.agent.updateUpAxis = false;
            this.agent.speed = speed;
            RandomPositionSpawns(directorAI);

        }
        private void Update()
        {

            if (enemySight.canSee)
            {
                isAttack = true;
                Debug.Log("Enter State_Hunting");
                EnterState(state_Hunting);
            }

            if (!enemySight.canSee && !isAttack && currentState != state_Listening)
            {   
                Debug.Log("Enter State_Listening");
                EnterState(state_Listening);
            }

            if(Vector2.Distance(transform.position,targetPosition) <= 0.5f && currentState != state_Searching)
            {   
                Debug.Log("Enter State_Searching");
                StartCoroutine(DelayTime(2f));
                EnterState(state_Searching);
            }
            if (hp <= 0)
            {
                isAttack = false;
                Debug.Log("Enter State_Retreat");
                EnterState(state_Retreat);
            }

        }
    }
}
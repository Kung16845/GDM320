using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Enemy_State
{
    public class State_Searching : StateMachine
    {   
        public override void Behavevior(Enemy enemy)
        {   
            var movetoRoom = enemy.directorAI.FindClosestPosition(enemy.directorAI.listRoomPosition
                                                                    ,enemy.directorAI.player);
            enemy.targetPosition = movetoRoom.position;
            enemy.agent.SetDestination(movetoRoom.position);
        }       
    }
}


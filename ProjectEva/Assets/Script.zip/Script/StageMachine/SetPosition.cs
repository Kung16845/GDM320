using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Enemy_State
{
    [Serializable]
    public class SetPosition
    {
        public string namePoint;
        public Transform point;
        
    }
}

